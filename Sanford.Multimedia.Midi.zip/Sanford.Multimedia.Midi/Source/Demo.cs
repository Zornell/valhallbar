﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace Sanford.Multimedia.Midi
{
    public class Demo
    {
        private const int Shift = 8;

        private const string InputFile =
            @"C:\Users\Ruben\Desktop\valhallbar\sounds\technoviking_all.mid";

        private const int VelocityRange = 127 / 4;

        public static void Main()
        {
            var tempo = 100;

            var sb = new StringBuilder();

            var sequence = new Sequence(InputFile);
            foreach (var track in sequence)
            {
                foreach (var midiEvent in track.Iterator())
                {
                    var message = midiEvent.MidiMessage;
                    UpdateTempo(message, ref tempo);

                    if (message.MessageType != MessageType.Channel) continue;

                    var channelMessage = (ChannelMessage)message;

                    if (channelMessage.Command == ChannelCommand.NoteOn)
                    {
                        var absoluteTicks = (double)midiEvent.AbsoluteTicks;
                        var noteValue = channelMessage.Data1;
                        var velocity = channelMessage.Data2;

                        var beat = absoluteTicks / sequence.Division;
                        var time = beat / tempo;
                        var millis = TimeSpan.FromMinutes(time).TotalMilliseconds;

                        var enemyType = velocity / VelocityRange;
                        var lane = noteValue - 60;

                        sb.AppendFormat("{0},{1},{2}\r\n", millis, lane, enemyType);
                    }
                }
            }

            var output = Path.ChangeExtension(InputFile, "txt");

            File.WriteAllText(output, sb.ToString());
        }

        private static void UpdateTempo(IMidiMessage message, ref int tempo)
        {
            if (message.MessageType == MessageType.Meta)
            {
                var metaMessage = (MetaMessage) message;
                if (metaMessage.MetaType == MetaType.Tempo)
                {
                    var builder = new TempoChangeBuilder(metaMessage);
                    builder.Build();
                    tempo = 60000000 / builder.Tempo;
                }
            }
        }
    }
}